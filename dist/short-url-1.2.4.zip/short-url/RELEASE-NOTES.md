# Short URL - Version 1.2.4 "CompatMaster"

This release fixes the translation loading warning in WordPress 6.7 and improves compatibility with the latest WordPress version.

## What's New

- 🐛 Fixed translation loading too early warning in WordPress 6.7
- 🔧 Improved compatibility with the latest WordPress version

